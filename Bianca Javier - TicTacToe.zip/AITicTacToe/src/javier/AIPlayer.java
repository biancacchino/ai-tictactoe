package javier;

import java.util.HashMap;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class AIPlayer {
	
	// These parameters handle how much effect new rewards have on q-values, how much long term rewards are valued
	private double learningRate = 0.5;
	private double discountFactor = 0.75;


	
	private static final Random rng = new Random();
	// As it plays, the AI generates a 'memory' of State-Action plays
	// The state is the current look of the board, and the action is the move the AI chooses to take
	// Over time, better moves will have a higher "q-value" indicating they are then more optimal choice
	// In this HashMap, the string is formated as BoardState-Action, for example
	//"X_O_X_-2" the board state is "X_O_X" and the chosen action is 2 (choose space 2 for the move)
	private HashMap<String, Double> memory = new HashMap<String, Double>();
	
	public AIPlayer() {
	
	}
	
	
	/**
	 * Examine the given TicTacToe board and choose a valid move. Move is returned as an int
	 * representing the selected move so the controller can execute the move as if a user player
	 * had chosen it
	 * 
	 * @param game, a TicTacToe game that is still playing (i.e. there is a valid move available)
	 * @return int representing the location where the AI wants to move
	 */
	public int chooseMove(TicTacToe game, double explore) {
	    // Ensure the game can still make a move; that the game isn't over
	    if (game.getStatus() != GameStatus.STILL_PLAYING) return -1;
	    
	    // Get a string to represent the current state of the board
	    String state = game.toString();
//	    System.out.println("AI choosing move... board state: " + state);
	    // See if we've seen this board before
	    List<Entry<String, Double>> previousActions = memory.entrySet().stream()
	            .filter(entry -> entry.getKey().startsWith(state))
	            .collect(Collectors.toList());
	    
	    // Explore (never seen this state or with probability explore)
	    if (previousActions.isEmpty() || rng.nextDouble() < explore) {
	        List<Integer> possibleActions = listAllMoves(state);
	        if (!possibleActions.isEmpty()) {
	        	
	            return possibleActions.get(rng.nextInt(possibleActions.size()));
	        } else {
	            // Handle the case where there are no possible moves
	            return -1;
	        }
	    }

	    // Exploit (seen this state)
	    // find the best previous q-value
	    double maxQValue = previousActions.stream()
	            .map(Map.Entry::getValue)
	            .max(Double::compare)
	            .orElse(0.0);

	    // Get a list of all actions that have this q-value
	    List<String> tiedActions = previousActions.stream()
	            .filter(entry -> entry.getValue().equals(maxQValue))
	            .map(Map.Entry::getKey)
	            .collect(Collectors.toList());

	    // Randomly select one of the tied actions
	    String chosenAction = tiedActions.get(rng.nextInt(tiedActions.size()));

	    // The action is the digit at the end of the string. So find it and return it
	    return Character.getNumericValue(chosenAction.charAt(chosenAction.length() - 1));
	}

	
	/**
	 * Given a particular game state, create a list of all valid moves
	 * @param game
	 * @return
	 */
	private List<Integer> listAllMoves(String game) {
		 List<Integer> validMoves = new ArrayList<Integer>();
		 StringBuilder temp = new StringBuilder(game);
		 
		 for (int move = 0; move < 9; move++) {
			 if (temp.charAt(move) == '_') {
				 validMoves.add(move);
			 }
		 }
		 
		 return validMoves;
	}
	
	/**
	 * Assign reward points based on he outcome of a given move
	 */
	private double getReward(TicTacToe game) {
		switch(game.getStatus()) {
		case X_WINS:
		case O_WINS:
			return 10.0;
		case TIE:
			return 5.0;
		default:
			return 0.0;
		}
	}
	

	
	/**
	 * Create a new reinforcement learning AI player
	 * @param learningRate - factor that describes how much impact new rewards have over previous knowledge
	 * @param discountFactor - factor that describes how much long term rewards are values
	 */
	public AIPlayer (double learningRate, double discountFactor) {
		this.learningRate = learningRate;
		this.discountFactor = discountFactor;
	}
	
	/**
	 * Update the reward for a given move choice
	 * @param state
	 * @param action
	 * @param reward
	 * @param nextState
	 */
	public void updateQValue(String stateAction, double reward, String nextState) {
		double currentQValue = memory.getOrDefault(stateAction,  0.0);
		
		// Find the maximum Q-Value for the next state
		double maxNextQValue = memory.entrySet().stream()
				.filter(entry -> entry.getKey().startsWith(nextState))
				.map(Map.Entry::getValue)
				.max(Double::compare)
				.orElse(0.0);
		
		// Update the Q-Value using Q-learning update rule
		double newQValue = currentQValue + learningRate * (reward - discountFactor * maxNextQValue - currentQValue);
		
		// Update Q-table
		memory.put(stateAction, newQValue);
	}
	
	
	/**
	 * Train the AI by playing multiple games and updating Q-values
	 * @param numGames
	 */
	public void train(int numGames) {
		System.out.println("Starting training games...");
		for (int i = 0; i < numGames; i++) {
			System.out.println("Game " + i);
			
			playGame();
		}
		System.out.println("Done training");
		System.out.println(memory.size() + " state-action pairs remembered.");
	}
	
	// Simulate playing a game using the current Q-learning strategy
	private void playGame() {
		TicTacToe game = new TicTacToe();
		Token currentPlayer = Token.X;
		
		while (game.getStatus() == GameStatus.STILL_PLAYING) {
			// Choose a move for the currentPlayer
			int move = chooseMove(game, 0.50);
			String stateAction = new StringBuilder(game.toString()).append("-").append(move).toString();
			System.out.println(stateAction);
			
			int row = move / 3;
			int col = move % 3;
			
			// Apply the move in the game
			game.play(col, row, currentPlayer);
			
			String postState = game.toString();
			
			// Update the q-value for this move
			this.updateQValue(stateAction, getReward(game), postState);
			
			// Switch player
			currentPlayer = (currentPlayer == Token.X) ? Token.O : Token.X;
		}
	}
	

}

