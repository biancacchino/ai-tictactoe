package javier;

import java.util.Optional;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Interface extends Application {

	// Set up the rows and columns for the TicTacToe board
	private int rows = 3;
	private int cols = 3;
	
	// Creates a 2D array of Buttons to represent board
	private Button[][] board = new Button[rows][cols];
	
	// Buttons for controlling the game
	private static Button train = new Button("Train");
	private static Button newGame = new Button("New Game");
	
	// Buttons for the player to select their symbol (X or O)
	private static Button playX = new Button("X");
	private static Button playO = new Button("O");
	
	// Constants represents the possible states of a cell on the board
	public static final int OPEN = 0;
	public static final int X = 1;
	public static final int O = 2;
	
	// Current state of the TicTacToe game
	private TicTacToe currentGame = new TicTacToe();
	
	// Initializing an AIPlayer for automated moves
	private AIPlayer ai = new AIPlayer();
	
	// Tokens representing the Player & AI pieces on the board
	private Token player = Token.EMPTY;
	private Token aiPiece = Token.EMPTY;
	
	
	// ---- Boxes ---- //
	VBox vbox = new VBox(10);			
	HBox rowBox = new HBox(10);
	HBox buttons = new HBox(50);
	HBox options = new HBox(50);
	
	// ---- Group ---- //
	private Group root = new Group();
	
	/**
	 * Start method for the program
	 */

	public void start(Stage primaryStage) throws Exception {
		
		

		
		// Create the buttons for the tic tac toe board
		for (int i = 0; i < rows; i++) {
			HBox rowBox = new HBox(10);
			
			for (int j = 0; j < cols; j++) {
				board[i][j] = new Button();
				
				// set the size of the buttons
				board[i][j].setMinSize(100, 100);
				
				// add button to hbox
				rowBox.getChildren().add(board[i][j]);
				
				// give the buttons meaning to live
				int finalI = i;
				int finalJ = j;
				board[i][j].setOnAction(e -> placePiece(finalI,finalJ));
				
			}
			
			vbox.getChildren().add(rowBox);
			
		}
		
		vbox.relocate(150, 100);
		
		newGame.setOnAction(e -> newGame());
		train.setOnAction(e -> trainAI());
		
		buttons.getChildren().addAll(train,newGame);
		buttons.relocate(400,500);
		
		options.getChildren().addAll(playX, playO);
		
		// When a player chooses to play X
		playX.setOnAction(e -> {
			player = Token.X;
			aiPiece = Token.O;
		});
		
		// When a player chooses to play O
		playO.setOnAction(e -> {
			player = Token.O;
			aiPiece = Token.X;
		});
		
		// Prompts user to choose
		Text whichToken = new Text("Which piece would you like to play?");
		VBox pickToken = new VBox(30);
		pickToken.getChildren().addAll(whichToken, options);
		pickToken.relocate(100, 500);
		
		root.getChildren().addAll(pickToken, vbox, buttons);
		
		Scene scene = new Scene(root, 600,600);
		primaryStage.setTitle("Bianca's tic tac toe");
		primaryStage.setScene(scene);
		primaryStage.show();
	}
		
	/**
	 * Handles placing a piece on the board
	 * @param col - column where player can place
	 * @param row - row where player can place
	 */
	private void placePiece(int col, int row) {
		// Disables choosing token mid game
		playX.setDisable(true);
		playO.setDisable(true);
		
		// Test to see if the player can actually play here
		if (currentGame.play(col, row, player)) {
			// Set button to the player's token
			String tokenString = player.toString();
			board[col][row].setText(tokenString);
			board[col][row].setDisable(true);
			
			// Check if the game is still running 
			if (currentGame.getStatus() == GameStatus.STILL_PLAYING) {
				// AI choosing a move and updating board
				// Call the choose 
				int aiMove = ai.chooseMove(currentGame, 0.0);
				int r = aiMove / 3;
				int c = aiMove % 3;
				
				// Place piece on board
				currentGame.play(c, r, aiPiece);
				
				// Set and disable that place
				board[c][r].setText(aiPiece.toString());
				board[c][r].setDisable(true);
				

			}
			
			// Check for a winner
			if (currentGame.getStatus() == GameStatus.X_WINS) {
				playAgain();
			} else if (currentGame.getStatus() == GameStatus.O_WINS) {
				playAgain();
			} else if (currentGame.getStatus() == GameStatus.TIE) {
				playAgain();
			}
			
		}
	}



	/**
	 * Displays Alert asking if user wants to play again
	 */

	private void playAgain() {
		// Creating warning message
		Alert msgBox = new Alert(AlertType.WARNING);
		
		// Checking if player X won
		if (currentGame.getStatus() == GameStatus.X_WINS) {
			// Sets content 
			msgBox.setContentText("X has won\nWanna play again?");
		} else if (currentGame.getStatus() == GameStatus.O_WINS) {
			msgBox.setContentText("O has won\nWanna play again?");
		} else if (currentGame.getStatus() == GameStatus.TIE) {
			msgBox.setContentText("Tie!\nWanna play again?");
		}
		
		// Removing header
		msgBox.setHeaderText(null);
		msgBox.getButtonTypes().clear();
		msgBox.getButtonTypes().addAll(ButtonType.YES, ButtonType.NO);
		
		// Get responses from user
		Optional<ButtonType> response = msgBox.showAndWait();
		
		// Close program
		if (response.isPresent() && response.get() == ButtonType.NO) {
			System.exit(0);
		}
		
		// Start new game
		else if (response.isPresent() && response.get() == ButtonType.YES) {
			newGame();
		}
		
		else {
			System.exit(0);
		}
	}
	/**
	 * Resets TicTacToe Board
	 */
	public void newGame() {
		// Enables ability to select a type
		playX.setDisable(false);
		playO.setDisable(false);
		
		// Create new Instance
		currentGame = new TicTacToe();
		
		// Resets Tokens for AI/Player
		player = Token.EMPTY;
		aiPiece = Token.EMPTY;
		
		// Cycle through each button and clears its text
		for (int i = 0; i < rows; i++ ) {
			for (int j = 0; j < cols; j++) {
				board[i][j].setText("");
				
				// Enables buttons
				board[i][j].setDisable(false);
			}
		}
	}

	/**
	 * Accesses the AIPlayer class to train
	 */
	public void trainAI() {
		// Calls the training method in the AIPlayer class
		// int = how many games bro will play
		ai.train(1000);
	}
	
	
	/**
	 * Main method for the program
	 * @param args
	 */
	
	public static void main(String[] args) {
		launch();
	}

}
