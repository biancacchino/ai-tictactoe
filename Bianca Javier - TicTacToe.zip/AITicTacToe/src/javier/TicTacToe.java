package javier;

public class TicTacToe {
	//create the 3x3 grid of "Token" - a Token is X, 0 or EMPTY
	
	private int col = 3;
	private int row = 3;
	
	private Token[][] board = new Token[col][row];
	public GameStatus status = GameStatus.STILL_PLAYING;
	/**
	 * Create a new TicTacToe game, which is a board will all empty squares
	 */
	public TicTacToe() {
		//initialize the board as completely empty
		for (int col = 0; col < 3; col++) {
			for (int row = 0; row < 3; row++) {
				board [col][row] = Token.EMPTY;
			}
		}
	}
	
   /**
    * Get the Token at the specified row and column.
    *
    * @param col - The column
    * @param row - The row
    * @return Token at the specified position
    */
   public Token getTokenAt(int col, int row) {
       // Add bounds checking to ensure col and row are within valid range
       if (col < 0 || col >= 3 || row < 0 || row >= 3) {
           throw new IllegalArgumentException("Invalid column or row");
       }
       return board[col][row];
   }
	
	/**
	 * Tests to see if a location is available for play
	 * @param space
	 * @return true if the location is empty
	 */
	public boolean isEmpty (int col, int row) {
		//guard statements (make sure the column and row are valid locations)
		if (col < 0 || col >= 3) return false;
		if (row < 0 || row >= 3) return false;
		return board [col][row] == Token.EMPTY;
	}
	/**
	 * Play the given token at the stated location, if possible
	 * @param col - The column to be played in
	 * @param row - The row to be played in
	 * @param player - Token to be played
	 * @return - True if the play is successful, false otherwise
	 */
	public boolean play(int col, int row, Token player) {
		//guard statements to make sure the intended play is valid
		if (status != GameStatus.STILL_PLAYING) return false;
		//guard statements to make sure the column and row numbers are valid
		if (col < 0 || col >= 3) return false;
		if (row < 0 || row >= 3) return false;
		//guard statement to make sure the space is actually empty
		if (board[col][row] != Token.EMPTY) return false;
		//guard statement to make sure a proper player token is provided
		if (!(player == Token.X || player == Token.O)) return false;
		board [col][row] = player; updateStatus();
		return true;
	}
	/**
	 *
	 * Update the status of the board after a valid move is recorded
	 */
	private void updateStatus() {
		if (testWinner(Token.X)) {
			status = GameStatus.X_WINS;
		}
		else if (testWinner(Token.O)) {
			status = GameStatus.O_WINS;
		}
		else if (testCats()) {
			status = GameStatus.TIE;
		}
		else {
			status = GameStatus.STILL_PLAYING;
		}
	}
	/**
	 * Test to see if the given player token has won the game
	 * @param player
	 * @return true if the token has won
	 */
	private boolean testWinner(Token player) {
		if (testLine(0,0, 0, 1, 0, 2, player)) return true;
		if (testLine(1,0, 1, 1, 1, 2, player)) return true;
		if (testLine(2,0, 2, 1, 2, 2, player)) return true;
		if (testLine(0,0, 1, 0, 2, 0, player)) return true;
		if (testLine(0,1, 1, 1, 2, 1, player)) return true;
		if (testLine(0,2, 1, 2, 2, 2, player)) return true;
		if (testLine(0,0, 1, 1, 2, 2, player)) return true;
		if (testLine(0,2, 1, 1, 2, 0, player)) return true;
		return false;
	}
	/**
	 * Test to see if a given set of three spaces all have the same player token
	 * @param colA, colB
	 - the first location
	 * @param colB, row - the second location
	 * @param colC, row - the third location
	 * @param player
	 * @return true if all three spaces have the given token
	 */
	private boolean testLine (int colA, int rowA, int colB, int rowB, int colC, int rowC, Token player) {
		return board[colA][rowA] == player && board[colB][rowB] == player && board[colC][rowC] == player;
	}
	/**
	 * Test to see if the game has ended by filling the entire board
	 * @return true if there are no more spaces to play
	 */
	private boolean testCats() {
	    for (int col = 0; col < 3; col++) {
	        for (int row = 0; row < 3; row++) {
	            if (board[col][row] == Token.EMPTY) {
	                // If any empty space is found, the game is not a tie
	                return false;
	            }
	        }
	    }
	    // If no empty space is found, the game is a tie
	    return true;
	}
	public GameStatus getStatus() {
	    return status;
	}
	
	public String toString() {
		StringBuilder temp = new StringBuilder();
       for (int row = 0; row < 3; row++) {
       	for (int col = 0; col < 3; col++) {
	        	if (board[col][row] == Token.EMPTY)
	        		temp.append("_");
	        	else
	        		temp.append(board[col][row]);
	        }
	    }
	   
	    return temp.toString();
	}
}
