package javier;

public enum GameStatus {
	STILL_PLAYING, X_WINS, O_WINS, TIE;
}
