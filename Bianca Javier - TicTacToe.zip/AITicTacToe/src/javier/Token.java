package javier;

public enum Token {
	  X, O, EMPTY;
	   public String toString() {
	       return name(); // Returns the name of the enum constant (X, O, EMPTY)
	   }
}
